package dk.sdu.mmmi.cbse.common.events;

import java.io.Serializable;

/**
 *
 * @author Mads and Jan
 */
public enum EventType implements Serializable{
    PLAYER_SHOOT, ENEMY_SHOOT, ASTEROID_SPLIT;
}
