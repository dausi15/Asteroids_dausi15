package dk.sdu.mmmi.cbse.common.data;

import java.io.Serializable;

/**
 *
 * @author jcs
 */
public enum EntityType implements Serializable {
    PLAYER, ENEMY, BULLET, ASTEROIDS;
}
